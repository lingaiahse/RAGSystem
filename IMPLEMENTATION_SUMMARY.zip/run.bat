@echo off
REM Churn Prediction Project - Run Scripts for Windows

echo =========================================
echo Churn Prediction Project
echo =========================================
echo.
echo Select option:
echo 1. Run quick start (app.py)
echo 2. Run full training pipeline (main.py)
echo 3. Start API server
echo 4. Run with Docker
echo 5. Stop Docker containers
echo.

set /p choice="Enter choice [1-5]: "

if %choice%==1 (
    echo Running quick start...
    python app.py
) else if %choice%==2 (
    echo Running full training pipeline...
    python main.py
) else if %choice%==3 (
    echo Starting API server...
    python -m uvicorn api.main:app --reload --port 8000
) else if %choice%==4 (
    echo Building and running Docker container...
    docker-compose up -d
    echo ✅ API running at http://localhost:8000
    echo 📚 API docs at http://localhost:8000/docs
) else if %choice%==5 (
    echo Stopping Docker containers...
    docker-compose down
    echo ✅ Containers stopped
) else (
    echo Invalid option
)

pause
