"""
Quick start script for Churn Prediction Project
For full pipeline with EDA and API, run: python main.py
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))

from src.data_processing import DataProcessor
from src.eda import EDAAnalyzer
from src.model_training import ModelTrainer
from src.model_evaluation import ModelEvaluator
from src.utils import print_section

if __name__ == "__main__":
    # Quick preview of data and model
    print_section("CHURN PREDICTION - QUICK START")
    
    # Load data
    processor = DataProcessor()
    df = processor.load_data()
    
    print("\n📊 Dataset Preview:")
    print(df.head())
    print(f"\n📈 Dataset Shape: {df.shape}")
    print(f"📋 Columns: {df.columns.tolist()}")
    
    # Process data (includes cleaning, conversion, NaN handling)
    X, y = processor.process_data(df)
    
    print(f"\n✅ Data processed - Shape: {X.shape}")
    print(f"✅ Churn distribution:\n{y.value_counts()}")
    print(f"✅ Churn rate: {y.mean():.2%}")
    
    # Quick model training
    print("\n" + "="*60)
    print("Running quick model training...")
    print("="*60)
    
    trainer = ModelTrainer()
    X_train, X_test, y_train, y_test = trainer.prepare_data(df)
    X_train_transformed, X_test_transformed = trainer.transform_data(X_train, X_test)
    
    # Train
    trainer.train_random_forest(X_train_transformed, y_train)
    metrics = trainer.evaluate_model(X_train_transformed, X_test_transformed, y_train, y_test)
    trainer.save_model()
    
    print("\n" + "="*60)
    print("✅ Quick start completed!")
    print("="*60)
    print("\n📌 Next Steps:")
    print("1. Run full pipeline: python main.py")
    print("2. Start API server: python -m uvicorn api.main:app --reload")
    print("3. Open API docs: http://localhost:8000/docs")
    print("\n📁 Check notebooks/ folder for visualizations")
    print("📦 Check model/ folder for saved models")
