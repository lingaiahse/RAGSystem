"""
Main training and orchestration script
"""

import sys
import pandas as pd
from pathlib import Path

# Add project to path
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

from src.utils import setup_logger, print_section, save_metadata
from src.data_processing import DataProcessor
from src.eda import EDAAnalyzer
from src.model_training import ModelTrainer
from src.model_evaluation import ModelEvaluator
from src.config import MODEL_METADATA

logger = setup_logger(__name__)


def main():
    """Main training pipeline"""
    
    print_section("CHURN PREDICTION - COMPLETE PIPELINE")
    
    # ========== 1. LOAD DATA ==========
    print_section("STEP 1: LOADING DATA")
    processor = DataProcessor()
    df = processor.load_data()
    
    # ========== 2. EXPLORATORY DATA ANALYSIS ==========
    print_section("STEP 2: EXPLORATORY DATA ANALYSIS")
    eda = EDAAnalyzer(df)
    eda.generate_report()
    eda.generate_visualizations()
    
    # ========== 3. DATA PROCESSING ==========
    print_section("STEP 3: DATA PROCESSING")
    X, y = processor.process_data(df)
    print(f"Features shape: {X.shape}")
    print(f"Target shape: {y.shape}")
    print(f"Churn rate: {y.mean():.2%}")
    
    # ========== 4. TRAIN/TEST SPLIT AND PREPROCESSING ==========
    print_section("STEP 4: PREPARING TRAINING DATA")
    trainer = ModelTrainer()
    X_train, X_test, y_train, y_test = trainer.prepare_data(df)
    
    # Transform data
    X_train_transformed, X_test_transformed = trainer.transform_data(X_train, X_test)
    
    # ========== 5. MODEL TRAINING ==========
    print_section("STEP 5: MODEL TRAINING")
    
    # Train Random Forest
    cv_scores_rf = trainer.train_random_forest(X_train_transformed, y_train)
    
    # ========== 6. MODEL EVALUATION ==========
    print_section("STEP 6: MODEL EVALUATION")
    metrics = trainer.evaluate_model(X_train_transformed, X_test_transformed,
                                    y_train, y_test)
    
    # ========== 7. FEATURE IMPORTANCE ==========
    print_section("STEP 7: FEATURE IMPORTANCE")
    feature_importance = trainer.get_feature_importance()
    
    # ========== 8. GENERATE EVALUATION VISUALIZATIONS ==========
    print_section("STEP 8: GENERATING EVALUATION VISUALIZATIONS")
    y_test_pred = trainer.predict(X_test_transformed)
    y_test_pred_proba = trainer.predict_proba(X_test_transformed)[:, 1]
    
    ModelEvaluator.generate_visualizations(
        y_test, y_test_pred, y_test_pred_proba,
        feature_importance, output_dir='./notebooks'
    )
    
    # ========== 9. SAVE MODEL ==========
    print_section("STEP 9: SAVING MODEL")
    trainer.save_model()
    
    # Save metadata
    metadata = {
        'model_type': type(trainer.model).__name__,
        'training_samples': len(X_train),
        'test_samples': len(X_test),
        'total_features': len(trainer.data_processor.feature_names or []),
        'categorical_features': len([f for f in trainer.data_processor.feature_names or [] if 'onehot' in str(f)]),
        'numerical_features': len([f for f in trainer.data_processor.feature_names or [] if 'scaler' in str(f)]),
        'train_metrics': metrics['train'],
        'test_metrics': metrics['test'],
        'cv_scores': cv_scores_rf
    }
    save_metadata(metadata, MODEL_METADATA)
    
    print_section("PIPELINE COMPLETED SUCCESSFULLY")
    print(f"✓ Model saved to model/churn_model.pkl")
    print(f"✓ Preprocessor saved to model/preprocessor.pkl")
    print(f"✓ Metadata saved to model/model_metadata.json")
    print(f"✓ Visualizations saved to notebooks/")
    print(f"✓ Training data saved to model/train_data.csv")
    print(f"✓ Test data saved to model/test_data.csv")
    
    return trainer, metrics


if __name__ == "__main__":
    trainer, metrics = main()
