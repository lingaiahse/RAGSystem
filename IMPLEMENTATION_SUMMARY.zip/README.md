# Churn Prediction Project

Complete machine learning pipeline for customer churn prediction with production-ready code structure.

## Project Structure

```
ChurnProject/
├── src/                      # Source code
│   ├── __init__.py
│   ├── config.py            # Configuration and constants
│   ├── utils.py             # Utility functions
│   ├── data_processing.py   # Data cleaning and preprocessing
│   ├── eda.py               # Exploratory data analysis
│   ├── model_training.py    # Model training
│   └── model_evaluation.py  # Model evaluation and metrics
├── api/                      # FastAPI application
│   ├── __init__.py
│   └── main.py              # API endpoints
├── model/                    # Saved models
│   ├── churn_model.pkl
│   ├── preprocessor.pkl
│   ├── model_metadata.json
│   ├── train_data.csv
│   └── test_data.csv
├── DataSet/                  # Dataset
│   └── telco_churn.csv
├── notebooks/               # Generated visualizations and EDA outputs
├── logs/                    # Application logs
├── main.py                  # Main training pipeline
├── Dockerfile               # Docker configuration
├── docker-compose.yml       # Docker Compose configuration
├── requirements.txt         # Python dependencies
└── README.md               # This file
```

## Features

### Data Processing
- ✅ Data loading and validation
- ✅ Missing value handling
- ✅ Duplicate removal
- ✅ Feature engineering
- ✅ Categorical encoding
- ✅ Numerical scaling

### Exploratory Data Analysis
- ✅ Statistical summaries
- ✅ Distribution analysis
- ✅ Correlation analysis
- ✅ Class imbalance detection
- ✅ Automatic visualization generation

### Model Training
- ✅ Random Forest classifier
- ✅ Gradient Boosting classifier
- ✅ Cross-validation
- ✅ Hyperparameter optimization ready
- ✅ Feature importance analysis

### Model Evaluation
- ✅ Accuracy, Precision, Recall, F1-Score
- ✅ Confusion Matrix
- ✅ ROC-AUC analysis
- ✅ Precision-Recall curves
- ✅ Comprehensive classification reports

### API & Deployment
- ✅ FastAPI with Swagger documentation
- ✅ Single and batch prediction endpoints
- ✅ Model serving with preprocessing
- ✅ Health check endpoint
- ✅ Docker containerization
- ✅ Docker Compose orchestration

## Installation

### Prerequisites
- Python 3.10+
- Docker (optional)
- pip or conda

### Local Setup

1. **Clone/Download the project**
```bash
cd ChurnProject
```

2. **Install dependencies**
```bash
pip install -r requirements.txt
```

## Usage

### 1. Run Complete Pipeline

Train the model with EDA and evaluation:

```bash
python main.py
```

This will:
- Load and clean the data
- Generate EDA visualizations
- Train the model
- Evaluate performance
- Save model and artifacts

### 2. Start API Server

```bash
python -m uvicorn api.main:app --reload
```

Visit `http://localhost:8000/docs` for interactive API documentation.

### 3. Docker Deployment

**Build image:**
```bash
docker build -t churn-prediction:latest .
```

**Run container:**
```bash
docker run -p 8000:8000 churn-prediction:latest
```

**Using Docker Compose:**
```bash
docker-compose up -d
```

## API Endpoints

### Health Check
```bash
GET /health
```

### Single Prediction
```bash
POST /predict
Content-Type: application/json

{
  "gender": "Female",
  "SeniorCitizen": 0,
  "Partner": "Yes",
  "Dependents": "No",
  "tenure": 12,
  "PhoneService": "Yes",
  "MultipleLines": "No",
  "InternetService": "Fiber optic",
  "OnlineSecurity": "No",
  "OnlineBackup": "No",
  "DeviceProtection": "Yes",
  "TechSupport": "Yes",
  "StreamingTV": "Yes",
  "StreamingMovies": "Yes",
  "Contract": "Month-to-month",
  "PaperlessBilling": "Yes",
  "PaymentMethod": "Electronic check",
  "MonthlyCharges": 99.99,
  "TotalCharges": 1299.87
}
```

**Response:**
```json
{
  "prediction": 1,
  "probability_no_churn": 0.25,
  "probability_churn": 0.75,
  "risk_level": "HIGH",
  "timestamp": "2024-06-03T10:30:45.123456"
}
```

### Batch Prediction
```bash
POST /predict-batch
```

### Model Information
```bash
GET /model-info
```

## Model Performance

The trained model achieves:
- **Accuracy**: ~80%
- **Precision**: ~60%
- **Recall**: ~55%
- **F1-Score**: ~57%
- **ROC-AUC**: ~0.84

## Files Generated

After running `main.py`:

**Models:**
- `model/churn_model.pkl` - Trained Random Forest model
- `model/preprocessor.pkl` - Fitted preprocessor pipeline

**Data:**
- `model/train_data.csv` - Training set
- `model/test_data.csv` - Test set

**Metadata:**
- `model/model_metadata.json` - Training metrics

**Visualizations (in notebooks/):**
- `01_churn_distribution.png` - Target distribution
- `02_numerical_distributions.png` - Feature distributions
- `03_correlation_heatmap.png` - Feature correlations
- `04_churn_by_contract.png` - Churn by contract type
- `05_churn_by_internet_service.png` - Churn by internet service
- `confusion_matrix.png` - Model confusion matrix
- `roc_curve.png` - ROC curve
- `precision_recall_curve.png` - Precision-recall curve
- `feature_importance.png` - Top 20 features

## Configuration

Edit `src/config.py` to customize:
- Model hyperparameters
- Train/test split ratio
- Feature lists
- API settings
- Paths

## Logging

Logs are saved to `logs/` directory with timestamps. Check logs for:
- Data processing steps
- Model training progress
- API requests and errors

## Production Deployment

### Using Docker:

1. Build image
2. Push to registry
3. Deploy with Docker Compose or Kubernetes
4. Monitor health endpoints

### Using Cloud Platforms:

- AWS: ECR + ECS/Lambda
- GCP: Cloud Run / GKE
- Azure: Container Instances / AKS
- Heroku: Buildpacks

## Improvements & Extensions

- [ ] Implement cross-validation for hyperparameter tuning
- [ ] Add more feature engineering
- [ ] Try XGBoost, LightGBM models
- [ ] Add model versioning
- [ ] Implement retraining pipeline
- [ ] Add database for predictions logging
- [ ] Add authentication to API
- [ ] Deploy with Kubernetes
- [ ] Add monitoring and alerting
- [ ] Implement A/B testing

## Troubleshooting

**Model not loading:**
```bash
# Run training first
python main.py
```

**Port already in use:**
```bash
# Use different port
python -m uvicorn api.main:app --port 8001
```

**Docker build fails:**
```bash
# Clear cache and rebuild
docker build --no-cache -t churn-prediction:latest .
```

## License

MIT License

## Author

Created as a comprehensive churn prediction solution.
