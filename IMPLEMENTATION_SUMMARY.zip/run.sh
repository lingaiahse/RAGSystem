#!/bin/bash

# Churn Prediction Project - Run Scripts

echo "========================================="
echo "Churn Prediction Project"
echo "========================================="
echo ""
echo "Select option:"
echo "1. Run quick start (app.py)"
echo "2. Run full training pipeline (main.py)"
echo "3. Start API server"
echo "4. Run with Docker"
echo "5. Stop Docker containers"
echo ""
read -p "Enter choice [1-5]: " choice

case $choice in
    1)
        echo "Running quick start..."
        python app.py
        ;;
    2)
        echo "Running full training pipeline..."
        python main.py
        ;;
    3)
        echo "Starting API server..."
        python -m uvicorn api.main:app --reload --port 8000
        ;;
    4)
        echo "Building and running Docker container..."
        docker-compose up -d
        echo "✅ API running at http://localhost:8000"
        echo "📚 API docs at http://localhost:8000/docs"
        ;;
    5)
        echo "Stopping Docker containers..."
        docker-compose down
        echo "✅ Containers stopped"
        ;;
    *)
        echo "Invalid option"
        ;;
esac
