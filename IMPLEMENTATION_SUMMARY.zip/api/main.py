"""
FastAPI Application for Churn Prediction
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
import numpy as np
import pandas as pd
import joblib
import logging
from typing import List, Dict, Any
from datetime import datetime

from src.config import (
    MODEL_FILE, PREPROCESSOR_FILE, API_HOST, API_PORT,
    CATEGORICAL_FEATURES, NUMERICAL_FEATURES
)

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize FastAPI app
app = FastAPI(
    title="Customer Churn Prediction API",
    description="API for predicting customer churn",
    version="1.0.0"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Load model and preprocessor
try:
    model = joblib.load(MODEL_FILE)
    preprocessor = joblib.load(PREPROCESSOR_FILE)
    logger.info("Model and preprocessor loaded successfully")
except Exception as e:
    logger.error(f"Failed to load model: {e}")
    model = None
    preprocessor = None


# Pydantic models for request/response
class CustomerData(BaseModel):
    """Customer data for prediction"""
    gender: str
    SeniorCitizen: int = Field(..., ge=0, le=1)
    Partner: str
    Dependents: str
    tenure: int = Field(..., ge=0)
    PhoneService: str
    MultipleLines: str
    InternetService: str
    OnlineSecurity: str
    OnlineBackup: str
    DeviceProtection: str
    TechSupport: str
    StreamingTV: str
    StreamingMovies: str
    Contract: str
    PaperlessBilling: str
    PaymentMethod: str
    MonthlyCharges: float = Field(..., gt=0)
    TotalCharges: float = Field(..., ge=0)
    
    class Config:
        json_schema_extra = {
            "example": {
                "gender": "Female",
                "SeniorCitizen": 0,
                "Partner": "Yes",
                "Dependents": "No",
                "tenure": 1,
                "PhoneService": "No",
                "MultipleLines": "No phone service",
                "InternetService": "DSL",
                "OnlineSecurity": "No",
                "OnlineBackup": "Yes",
                "DeviceProtection": "No",
                "TechSupport": "No",
                "StreamingTV": "No",
                "StreamingMovies": "No",
                "Contract": "Month-to-month",
                "PaperlessBilling": "Yes",
                "PaymentMethod": "Electronic check",
                "MonthlyCharges": 29.85,
                "TotalCharges": 29.85
            }
        }


class PredictionResponse(BaseModel):
    """Prediction response"""
    prediction: int
    probability_no_churn: float
    probability_churn: float
    risk_level: str
    timestamp: str


class BatchPredictionRequest(BaseModel):
    """Batch prediction request"""
    customers: List[CustomerData]


class BatchPredictionResponse(BaseModel):
    """Batch prediction response"""
    predictions: List[PredictionResponse]
    total_customers: int
    customers_at_risk: int


class HealthResponse(BaseModel):
    """Health check response"""
    status: str
    model_loaded: bool
    timestamp: str


# API endpoints
@app.get("/health", response_model=HealthResponse)
async def health_check():
    """Health check endpoint"""
    return HealthResponse(
        status="healthy" if model is not None else "model_not_loaded",
        model_loaded=model is not None,
        timestamp=datetime.now().isoformat()
    )


@app.post("/predict", response_model=PredictionResponse)
async def predict_single(customer: CustomerData):
    """
    Predict churn for a single customer
    
    Args:
        customer: Customer data
        
    Returns:
        Prediction with probability and risk level
    """
    if model is None or preprocessor is None:
        raise HTTPException(status_code=503, detail="Model not loaded")
    
    try:
        # Prepare data
        customer_dict = customer.dict()
        df = pd.DataFrame([customer_dict])
        
        # Ensure correct order and select only needed features
        df = df[CATEGORICAL_FEATURES + NUMERICAL_FEATURES]
        
        # Preprocess
        X_processed = preprocessor.transform(df)
        
        # Predict
        prediction = model.predict(X_processed)[0]
        probabilities = model.predict_proba(X_processed)[0]
        
        # Determine risk level
        churn_probability = probabilities[1]
        if churn_probability >= 0.7:
            risk_level = "HIGH"
        elif churn_probability >= 0.4:
            risk_level = "MEDIUM"
        else:
            risk_level = "LOW"
        
        return PredictionResponse(
            prediction=int(prediction),
            probability_no_churn=float(probabilities[0]),
            probability_churn=float(probabilities[1]),
            risk_level=risk_level,
            timestamp=datetime.now().isoformat()
        )
    
    except Exception as e:
        logger.error(f"Prediction error: {e}")
        raise HTTPException(status_code=400, detail=f"Prediction failed: {str(e)}")


@app.post("/predict-batch", response_model=BatchPredictionResponse)
async def predict_batch(request: BatchPredictionRequest):
    """
    Predict churn for multiple customers
    
    Args:
        request: Batch prediction request
        
    Returns:
        Batch predictions
    """
    if model is None or preprocessor is None:
        raise HTTPException(status_code=503, detail="Model not loaded")
    
    try:
        predictions = []
        customers_at_risk = 0
        
        for customer in request.customers:
            customer_dict = customer.dict()
            df = pd.DataFrame([customer_dict])
            df = df[CATEGORICAL_FEATURES + NUMERICAL_FEATURES]
            
            X_processed = preprocessor.transform(df)
            prediction = model.predict(X_processed)[0]
            probabilities = model.predict_proba(X_processed)[0]
            
            churn_probability = probabilities[1]
            if churn_probability >= 0.7:
                risk_level = "HIGH"
                customers_at_risk += 1
            elif churn_probability >= 0.4:
                risk_level = "MEDIUM"
                customers_at_risk += 1
            else:
                risk_level = "LOW"
            
            predictions.append(PredictionResponse(
                prediction=int(prediction),
                probability_no_churn=float(probabilities[0]),
                probability_churn=float(probabilities[1]),
                risk_level=risk_level,
                timestamp=datetime.now().isoformat()
            ))
        
        return BatchPredictionResponse(
            predictions=predictions,
            total_customers=len(request.customers),
            customers_at_risk=customers_at_risk
        )
    
    except Exception as e:
        logger.error(f"Batch prediction error: {e}")
        raise HTTPException(status_code=400, detail=f"Batch prediction failed: {str(e)}")


@app.get("/model-info")
async def model_info():
    """Get model information"""
    if model is None:
        raise HTTPException(status_code=503, detail="Model not loaded")
    
    return {
        "model_type": type(model).__name__,
        "features": CATEGORICAL_FEATURES + NUMERICAL_FEATURES,
        "num_features": len(CATEGORICAL_FEATURES) + len(NUMERICAL_FEATURES),
        "categorical_features": CATEGORICAL_FEATURES,
        "numerical_features": NUMERICAL_FEATURES,
        "timestamp": datetime.now().isoformat()
    }


@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "message": "Customer Churn Prediction API",
        "version": "1.0.0",
        "endpoints": {
            "health": "/health",
            "predict": "/predict",
            "predict_batch": "/predict-batch",
            "model_info": "/model-info",
            "docs": "/docs"
        }
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host=API_HOST, port=API_PORT)
