"""
Exploratory Data Analysis for the Churn Prediction Project
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from typing import Dict

from src.utils import setup_logger, print_section

logger = setup_logger(__name__)


class EDAAnalyzer:
    """Perform exploratory data analysis"""
    
    def __init__(self, df: pd.DataFrame):
        self.df = df
        self.categorical_features = df.select_dtypes(include='object').columns.tolist()
        self.numerical_features = df.select_dtypes(include=['int64', 'float64']).columns.tolist()
    
    def basic_info(self) -> Dict:
        """
        Get basic dataset information
        
        Returns:
            Dictionary with basic info
        """
        print_section("BASIC DATASET INFORMATION")
        
        info = {
            'shape': self.df.shape,
            'columns': self.df.columns.tolist(),
            'dtypes': self.df.dtypes.to_dict(),
            'missing_values': self.df.isnull().sum().to_dict(),
            'duplicates': self.df.duplicated().sum()
        }
        
        print(f"Shape: {info['shape']}")
        print(f"\nData Types:\n{self.df.dtypes}")
        print(f"\nMissing Values:\n{self.df.isnull().sum()}")
        print(f"\nDuplicate Rows: {info['duplicates']}")
        
        return info
    
    def statistical_summary(self) -> pd.DataFrame:
        """
        Get statistical summary of numerical features
        
        Returns:
            Statistical summary DataFrame
        """
        print_section("STATISTICAL SUMMARY")
        
        summary = self.df.describe(include='all').T
        print(summary)
        
        return summary
    
    def class_distribution(self, target_col: str = 'Churn') -> Dict:
        """
        Analyze target variable distribution
        
        Args:
            target_col: Target column name
            
        Returns:
            Distribution dictionary
        """
        if target_col not in self.df.columns:
            logger.warning(f"Target column '{target_col}' not found")
            return {}
        
        print_section(f"TARGET VARIABLE DISTRIBUTION - {target_col}")
        
        distribution = self.df[target_col].value_counts()
        percentages = self.df[target_col].value_counts(normalize=True) * 100
        
        print(f"Value Counts:\n{distribution}")
        print(f"\nPercentages:\n{percentages}")
        
        return {
            'counts': distribution.to_dict(),
            'percentages': percentages.to_dict()
        }
    
    def categorical_analysis(self) -> Dict:
        """
        Analyze categorical features
        
        Returns:
            Analysis dictionary
        """
        print_section("CATEGORICAL FEATURES ANALYSIS")
        
        analysis = {}
        for col in self.categorical_features:
            if col != 'customerID':
                print(f"\n{col}:")
                value_counts = self.df[col].value_counts()
                print(value_counts)
                analysis[col] = value_counts.to_dict()
        
        return analysis
    
    def numerical_analysis(self):
        """
        Analyze numerical features
        
        Returns:
            Analysis dictionary
        """
        print_section("NUMERICAL FEATURES ANALYSIS")
        
        analysis = {}
        for col in self.numerical_features:
            print(f"\n{col}:")
            print(f"  Mean: {self.df[col].mean():.2f}")
            print(f"  Median: {self.df[col].median():.2f}")
            print(f"  Std: {self.df[col].std():.2f}")
            print(f"  Min: {self.df[col].min():.2f}")
            print(f"  Max: {self.df[col].max():.2f}")
            
            analysis[col] = {
                'mean': float(self.df[col].mean()),
                'median': float(self.df[col].median()),
                'std': float(self.df[col].std()),
                'min': float(self.df[col].min()),
                'max': float(self.df[col].max())
            }
        
        return analysis
    
    def correlation_analysis(self):
        """
        Analyze correlations between numerical features
        
        Returns:
            Correlation matrix
        """
        print_section("CORRELATION ANALYSIS")
        
        correlation_matrix = self.df[self.numerical_features].corr()
        print(correlation_matrix)
        
        return correlation_matrix
    
    def churn_correlation(self, target_col: str = 'Churn'):
        """
        Analyze correlation of features with churn
        
        Args:
            target_col: Target column name
        """
        if target_col not in self.df.columns:
            logger.warning(f"Target column '{target_col}' not found")
            return
        
        print_section(f"CHURN CORRELATION WITH FEATURES")
        
        # Prepare dataframe for correlation
        df_corr = self.df.copy()
        
        # Exclude ID columns
        exclude_cols = ['customerID', 'Unnamed: 0']
        
        # Convert categorical to numeric for correlation
        for col in self.categorical_features:
            if col not in exclude_cols:
                df_corr[col] = pd.factorize(df_corr[col])[0]
        
        # Convert target to numeric if needed
        if df_corr[target_col].dtype == 'object':
            df_corr[target_col] = pd.factorize(df_corr[target_col])[0]
        
        # Select only numeric columns for correlation
        numeric_cols = df_corr.select_dtypes(include=['int64', 'float64', 'int32', 'float32']).columns
        
        if target_col in numeric_cols:
            correlations = df_corr[numeric_cols].corr()[target_col].sort_values(ascending=False)
            print(correlations)
            return correlations
        else:
            logger.warning(f"Target column {target_col} is not numeric after conversion")
            return None
    
    def generate_visualizations(self, output_dir: str = './notebooks'):
        """
        Generate EDA visualizations
        
        Args:
            output_dir: Directory to save visualizations
        """
        print_section("GENERATING VISUALIZATIONS")
        
        import os
        os.makedirs(output_dir, exist_ok=True)
        
        # Set style
        sns.set_style("whitegrid")
        plt.rcParams['figure.figsize'] = (12, 6)
        
        # 1. Churn distribution
        plt.figure(figsize=(8, 5))
        if 'Churn' in self.df.columns:
            self.df['Churn'].value_counts().plot(kind='bar', color=['#2ecc71', '#e74c3c'])
            plt.title('Churn Distribution')
            plt.ylabel('Count')
            plt.xlabel('Churn')
            plt.tight_layout()
            plt.savefig(f'{output_dir}/01_churn_distribution.png', dpi=300, bbox_inches='tight')
            plt.close()
        
        # 2. Numerical features distribution
        plt.figure(figsize=(15, 8))
        for idx, col in enumerate(self.numerical_features[:4], 1):
            plt.subplot(2, 2, idx)
            plt.hist(self.df[col], bins=30, color='#3498db', edgecolor='black')
            plt.title(f'Distribution of {col}')
            plt.xlabel(col)
            plt.ylabel('Frequency')
        plt.tight_layout()
        plt.savefig(f'{output_dir}/02_numerical_distributions.png', dpi=300, bbox_inches='tight')
        plt.close()
        
        # 3. Correlation heatmap
        if len(self.numerical_features) > 1:
            plt.figure(figsize=(10, 8))
            correlation = self.df[self.numerical_features].corr()
            sns.heatmap(correlation, annot=True, fmt='.2f', cmap='coolwarm', center=0)
            plt.title('Correlation Matrix - Numerical Features')
            plt.tight_layout()
            plt.savefig(f'{output_dir}/03_correlation_heatmap.png', dpi=300, bbox_inches='tight')
            plt.close()
        
        # 4. Churn by Contract
        if 'Contract' in self.df.columns and 'Churn' in self.df.columns:
            plt.figure(figsize=(10, 6))
            churn_contract = pd.crosstab(self.df['Contract'], self.df['Churn'], normalize='index') * 100
            churn_contract.plot(kind='bar', color=['#2ecc71', '#e74c3c'])
            plt.title('Churn Rate by Contract Type')
            plt.ylabel('Percentage (%)')
            plt.xlabel('Contract Type')
            plt.legend(['No Churn', 'Churn'])
            plt.tight_layout()
            plt.savefig(f'{output_dir}/04_churn_by_contract.png', dpi=300, bbox_inches='tight')
            plt.close()
        
        # 5. Churn by Internet Service
        if 'InternetService' in self.df.columns and 'Churn' in self.df.columns:
            plt.figure(figsize=(10, 6))
            churn_internet = pd.crosstab(self.df['InternetService'], self.df['Churn'], normalize='index') * 100
            churn_internet.plot(kind='bar', color=['#2ecc71', '#e74c3c'])
            plt.title('Churn Rate by Internet Service')
            plt.ylabel('Percentage (%)')
            plt.xlabel('Internet Service')
            plt.legend(['No Churn', 'Churn'])
            plt.tight_layout()
            plt.savefig(f'{output_dir}/05_churn_by_internet_service.png', dpi=300, bbox_inches='tight')
            plt.close()
        
        logger.info(f"Visualizations saved to {output_dir}")
    
    def generate_report(self) -> str:
        """
        Generate comprehensive EDA report
        
        Returns:
            Report summary string
        """
        report = """
        ================================
        EXPLORATORY DATA ANALYSIS REPORT
        ================================
        """
        
        self.basic_info()
        self.statistical_summary()
        self.class_distribution()
        self.categorical_analysis()
        self.numerical_analysis()
        self.correlation_analysis()
        self.churn_correlation()
        
        return report
