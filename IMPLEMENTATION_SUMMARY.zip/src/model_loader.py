"""
Model loader utility for easy model management
"""

import joblib
from pathlib import Path
from typing import Tuple, Optional

from src.config import MODEL_FILE, PREPROCESSOR_FILE
from src.utils import setup_logger

logger = setup_logger(__name__)


class ModelLoader:
    """Load and manage trained models"""
    
    @staticmethod
    def load_model_and_preprocessor(
        model_path: str = None,
        preprocessor_path: str = None
    ) -> Tuple[Optional[object], Optional[object]]:
        """
        Load model and preprocessor
        
        Args:
            model_path: Path to model file
            preprocessor_path: Path to preprocessor file
            
        Returns:
            Tuple of (model, preprocessor)
        """
        if model_path is None:
            model_path = MODEL_FILE
        if preprocessor_path is None:
            preprocessor_path = PREPROCESSOR_FILE
        
        model = None
        preprocessor = None
        
        try:
            if Path(model_path).exists():
                model = joblib.load(model_path)
                logger.info(f"✅ Model loaded from {model_path}")
            else:
                logger.error(f"❌ Model not found at {model_path}")
        except Exception as e:
            logger.error(f"❌ Failed to load model: {e}")
        
        try:
            if Path(preprocessor_path).exists():
                preprocessor = joblib.load(preprocessor_path)
                logger.info(f"✅ Preprocessor loaded from {preprocessor_path}")
            else:
                logger.error(f"❌ Preprocessor not found at {preprocessor_path}")
        except Exception as e:
            logger.error(f"❌ Failed to load preprocessor: {e}")
        
        return model, preprocessor
    
    @staticmethod
    def check_model_exists(model_path: str = None) -> bool:
        """
        Check if model file exists
        
        Args:
            model_path: Path to model file
            
        Returns:
            True if exists, False otherwise
        """
        if model_path is None:
            model_path = MODEL_FILE
        return Path(model_path).exists()
    
    @staticmethod
    def get_model_info(model_path: str = None) -> dict:
        """
        Get model information
        
        Args:
            model_path: Path to model file
            
        Returns:
            Dictionary with model info
        """
        if model_path is None:
            model_path = MODEL_FILE
        
        path = Path(model_path)
        if path.exists():
            return {
                'exists': True,
                'path': str(path),
                'size_mb': path.stat().st_size / (1024 * 1024),
                'modified': path.stat().st_mtime
            }
        else:
            return {'exists': False, 'path': str(path)}
