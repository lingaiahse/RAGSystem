"""
Model evaluation and metrics for the Churn Prediction Project
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import (
    roc_curve, auc, confusion_matrix, classification_report,
    precision_recall_curve, f1_score
)
from typing import Dict, Tuple

from src.utils import setup_logger, print_section

logger = setup_logger(__name__)


class ModelEvaluator:
    """Evaluate model performance and generate reports"""
    
    @staticmethod
    def plot_confusion_matrix(y_true: np.ndarray, y_pred: np.ndarray,
                             output_path: str = './notebooks/confusion_matrix.png'):
        """
        Plot confusion matrix
        
        Args:
            y_true: True labels
            y_pred: Predicted labels
            output_path: Path to save plot
        """
        cm = confusion_matrix(y_true, y_pred)
        
        plt.figure(figsize=(8, 6))
        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', cbar=True,
                   xticklabels=['No Churn', 'Churn'],
                   yticklabels=['No Churn', 'Churn'])
        plt.title('Confusion Matrix')
        plt.ylabel('True Label')
        plt.xlabel('Predicted Label')
        plt.tight_layout()
        plt.savefig(output_path, dpi=300, bbox_inches='tight')
        plt.close()
        logger.info(f"Confusion matrix saved to {output_path}")
    
    @staticmethod
    def plot_roc_curve(y_true: np.ndarray, y_pred_proba: np.ndarray,
                      output_path: str = './notebooks/roc_curve.png'):
        """
        Plot ROC curve
        
        Args:
            y_true: True labels
            y_pred_proba: Predicted probabilities
            output_path: Path to save plot
        """
        fpr, tpr, thresholds = roc_curve(y_true, y_pred_proba)
        roc_auc = auc(fpr, tpr)
        
        plt.figure(figsize=(8, 6))
        plt.plot(fpr, tpr, color='darkorange', lw=2,
                label=f'ROC curve (AUC = {roc_auc:.2f})')
        plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--', label='Random')
        plt.xlim([0.0, 1.0])
        plt.ylim([0.0, 1.05])
        plt.xlabel('False Positive Rate')
        plt.ylabel('True Positive Rate')
        plt.title('Receiver Operating Characteristic (ROC) Curve')
        plt.legend(loc="lower right")
        plt.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.savefig(output_path, dpi=300, bbox_inches='tight')
        plt.close()
        logger.info(f"ROC curve saved to {output_path}")
    
    @staticmethod
    def plot_precision_recall_curve(y_true: np.ndarray, y_pred_proba: np.ndarray,
                                   output_path: str = './notebooks/precision_recall_curve.png'):
        """
        Plot Precision-Recall curve
        
        Args:
            y_true: True labels
            y_pred_proba: Predicted probabilities
            output_path: Path to save plot
        """
        precision, recall, thresholds = precision_recall_curve(y_true, y_pred_proba)
        f1_scores = 2 * (precision * recall) / (precision + recall + 1e-10)
        
        plt.figure(figsize=(8, 6))
        plt.plot(recall, precision, color='blue', lw=2,
                label=f'Precision-Recall curve')
        plt.xlabel('Recall')
        plt.ylabel('Precision')
        plt.title('Precision-Recall Curve')
        plt.legend(loc="best")
        plt.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.savefig(output_path, dpi=300, bbox_inches='tight')
        plt.close()
        logger.info(f"Precision-Recall curve saved to {output_path}")
    
    @staticmethod
    def plot_feature_importance(feature_importance_df: pd.DataFrame,
                               top_n: int = 20,
                               output_path: str = './notebooks/feature_importance.png'):
        """
        Plot feature importance
        
        Args:
            feature_importance_df: DataFrame with features and importance scores
            top_n: Number of top features to display
            output_path: Path to save plot
        """
        top_features = feature_importance_df.head(top_n)
        
        plt.figure(figsize=(10, 8))
        plt.barh(range(len(top_features)), top_features['importance'], color='steelblue')
        plt.yticks(range(len(top_features)), top_features['feature'])
        plt.xlabel('Importance')
        plt.title(f'Top {top_n} Feature Importance')
        plt.gca().invert_yaxis()
        plt.tight_layout()
        plt.savefig(output_path, dpi=300, bbox_inches='tight')
        plt.close()
        logger.info(f"Feature importance plot saved to {output_path}")
    
    @staticmethod
    def generate_evaluation_report(y_true: np.ndarray, y_pred: np.ndarray,
                                  y_pred_proba: np.ndarray = None) -> Dict:
        """
        Generate comprehensive evaluation report
        
        Args:
            y_true: True labels
            y_pred: Predicted labels
            y_pred_proba: Predicted probabilities
            
        Returns:
            Report dictionary
        """
        print_section("EVALUATION REPORT")
        
        report = {
            'confusion_matrix': confusion_matrix(y_true, y_pred).tolist(),
            'classification_report': classification_report(y_true, y_pred, output_dict=True)
        }
        
        if y_pred_proba is not None:
            fpr, tpr, _ = roc_curve(y_true, y_pred_proba)
            report['roc_auc'] = float(auc(fpr, tpr))
            report['fpr'] = fpr.tolist()
            report['tpr'] = tpr.tolist()
        
        # Print report
        print(f"\nConfusion Matrix:\n{np.array(report['confusion_matrix'])}")
        print(f"\nClassification Report:\n{classification_report(y_true, y_pred)}")
        if 'roc_auc' in report:
            print(f"\nROC AUC: {report['roc_auc']:.4f}")
        
        return report
    
    @staticmethod
    def generate_visualizations(y_true: np.ndarray, y_pred: np.ndarray,
                               y_pred_proba: np.ndarray,
                               feature_importance_df: pd.DataFrame = None,
                               output_dir: str = './notebooks'):
        """
        Generate all evaluation visualizations
        
        Args:
            y_true: True labels
            y_pred: Predicted labels
            y_pred_proba: Predicted probabilities
            feature_importance_df: Feature importance DataFrame
            output_dir: Directory to save plots
        """
        import os
        os.makedirs(output_dir, exist_ok=True)
        
        print_section("GENERATING EVALUATION VISUALIZATIONS")
        
        ModelEvaluator.plot_confusion_matrix(
            y_true, y_pred,
            f'{output_dir}/confusion_matrix.png'
        )
        
        ModelEvaluator.plot_roc_curve(
            y_true, y_pred_proba,
            f'{output_dir}/roc_curve.png'
        )
        
        ModelEvaluator.plot_precision_recall_curve(
            y_true, y_pred_proba,
            f'{output_dir}/precision_recall_curve.png'
        )
        
        if feature_importance_df is not None:
            ModelEvaluator.plot_feature_importance(
                feature_importance_df,
                top_n=20,
                output_path=f'{output_dir}/feature_importance.png'
            )
        
        logger.info(f"All visualizations saved to {output_dir}")
