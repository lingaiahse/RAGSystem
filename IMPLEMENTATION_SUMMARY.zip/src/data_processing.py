"""
Data processing and cleaning for the Churn Prediction Project
"""

import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
from typing import Tuple, Optional
import joblib

from src.config import (
    DATA_FILE, CATEGORICAL_FEATURES, NUMERICAL_FEATURES,
    TARGET_COLUMN, PREPROCESSOR_FILE, TRAIN_DATA_FILE, TEST_DATA_FILE
)
from src.utils import setup_logger

logger = setup_logger(__name__)


class DataProcessor:
    """Handle data loading, cleaning, and preprocessing"""
    
    def __init__(self):
        self.preprocessor = None
        self.feature_names = None
        
    def load_data(self, file_path: str = None) -> pd.DataFrame:
        """
        Load data from CSV file
        
        Args:
            file_path: Path to CSV file
            
        Returns:
            Loaded DataFrame
        """
        if file_path is None:
            file_path = DATA_FILE
            
        logger.info(f"Loading data from {file_path}")
        df = pd.read_csv(file_path)
        logger.info(f"Data shape: {df.shape}")
        return df
    
    def clean_data(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Clean the dataset
        
        Args:
            df: Input DataFrame
            
        Returns:
            Cleaned DataFrame
        """
        logger.info("Starting data cleaning...")
        
        # Remove duplicates
        initial_rows = len(df)
        df = df.drop_duplicates()
        logger.info(f"Removed {initial_rows - len(df)} duplicate rows")
        
        # Handle missing values
        # Drop customer ID as it's not useful for modeling
        if 'customerID' in df.columns:
            df = df.drop('customerID', axis=1)
        
        # Convert TotalCharges to numeric
        if 'TotalCharges' in df.columns:
            df['TotalCharges'] = pd.to_numeric(df['TotalCharges'], errors='coerce')
            missing_total_charges = df['TotalCharges'].isna().sum()
            if missing_total_charges > 0:
                logger.warning(f"Found {missing_total_charges} missing values in TotalCharges")
                df = df.dropna(subset=['TotalCharges'])
        
        # Handle empty strings in categorical columns
        for col in df.select_dtypes(include='object').columns:
            df[col] = df[col].replace('', np.nan)
            if df[col].isna().any():
                logger.warning(f"Found {df[col].isna().sum()} missing values in {col}")
                # Fill with mode or drop
                if len(df) > 0:
                    df[col] = df[col].fillna(df[col].mode()[0] if len(df[col].mode()) > 0 else 'Unknown')
        
        logger.info(f"Data cleaning completed. Final shape: {df.shape}")
        return df
    
    def convert_boolean_columns(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Convert boolean string columns to numeric
        
        Args:
            df: Input DataFrame
            
        Returns:
            DataFrame with boolean columns converted
        """
        logger.info("Converting boolean columns...")
        
        boolean_cols = ['SeniorCitizen', 'Partner', 'Dependents', 'PhoneService',
                       'MultipleLines', 'OnlineSecurity', 'OnlineBackup', 'DeviceProtection',
                       'TechSupport', 'StreamingTV', 'StreamingMovies', 'PaperlessBilling']
        
        for col in boolean_cols:
            if col in df.columns:
                # Skip conversion if already numeric
                if df[col].dtype in ['int64', 'int32', 'float64', 'float32']:
                    continue
                    
                # Handle object type (strings)
                if df[col].dtype == 'object':
                    # Create mapping function that handles multiple formats
                    def map_bool(val):
                        if pd.isna(val):
                            return 0  # Default for NaN
                        val_str = str(val).strip().lower()
                        if val_str in ['yes', 'true', '1']:
                            return 1
                        elif val_str in ['no', 'false', '0', 'no phone service', 'no internet service']:
                            return 0
                        else:
                            logger.warning(f"Unexpected value in {col}: {val_str}")
                            return 0  # Default for unexpected values
                    
                    df[col] = df[col].apply(map_bool)
                
                # Handle boolean type
                elif df[col].dtype == 'bool':
                    df[col] = df[col].astype(int)
        
        return df
    
    def convert_target(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Convert target variable to numeric
        
        Args:
            df: Input DataFrame
            
        Returns:
            DataFrame with converted target
        """
        if TARGET_COLUMN in df.columns:
            # Skip conversion if already numeric
            if df[TARGET_COLUMN].dtype not in ['int64', 'int32', 'float64', 'float32']:
                # Handle object type (strings)
                if df[TARGET_COLUMN].dtype == 'object':
                    def map_target(val):
                        if pd.isna(val):
                            return np.nan  # Keep NaN for later handling
                        val_str = str(val).strip().lower()
                        if val_str in ['yes', 'true', '1']:
                            return 1
                        elif val_str in ['no', 'false', '0']:
                            return 0
                        else:
                            logger.warning(f"Unexpected value in {TARGET_COLUMN}: {val_str}")
                            return np.nan  # Mark as NaN for dropping
                    
                    df[TARGET_COLUMN] = df[TARGET_COLUMN].apply(map_target)
                
                # Handle boolean type
                elif df[TARGET_COLUMN].dtype == 'bool':
                    df[TARGET_COLUMN] = df[TARGET_COLUMN].astype(int)
        
        return df
    
    def create_preprocessor(self):
        """
        Create preprocessing pipeline
        
        Returns:
            ColumnTransformer object
        """
        logger.info("Creating preprocessing pipeline...")
        
        # Numeric transformer: scaling
        numeric_transformer = Pipeline(steps=[
            ('scaler', StandardScaler())
        ])
        
        # Categorical transformer: one-hot encoding
        categorical_transformer = Pipeline(steps=[
            ('onehot', OneHotEncoder(drop='first', sparse_output=False, handle_unknown='ignore'))
        ])
        
        # Combine transformers
        self.preprocessor = ColumnTransformer(
            transformers=[
                ('num', numeric_transformer, NUMERICAL_FEATURES),
                ('cat', categorical_transformer, CATEGORICAL_FEATURES)
            ])
        
        return self.preprocessor
    
    def fit_preprocessor(self, X_train: pd.DataFrame) -> np.ndarray:
        """
        Fit the preprocessor on training data
        
        Args:
            X_train: Training features
            
        Returns:
            Transformed training data
        """
        logger.info("Fitting preprocessor on training data...")
        self.create_preprocessor()
        X_train_transformed = self.preprocessor.fit_transform(X_train)
        
        # Get feature names after transformation
        cat_features = self.preprocessor.named_transformers_['cat'].named_steps['onehot'].get_feature_names_out(CATEGORICAL_FEATURES)
        self.feature_names = list(NUMERICAL_FEATURES) + list(cat_features)
        
        logger.info(f"Preprocessor fitted. Total features: {len(self.feature_names)}")
        return X_train_transformed
    
    def transform_data(self, X: pd.DataFrame) -> np.ndarray:
        """
        Transform data using fitted preprocessor
        
        Args:
            X: Features to transform
            
        Returns:
            Transformed data
        """
        if self.preprocessor is None:
            raise ValueError("Preprocessor not fitted yet")
        return self.preprocessor.transform(X)
    
    def save_preprocessor(self, file_path: str = None):
        """
        Save preprocessor to disk
        
        Args:
            file_path: Path to save file
        """
        if file_path is None:
            file_path = PREPROCESSOR_FILE
        joblib.dump(self.preprocessor, file_path)
        logger.info(f"Preprocessor saved to {file_path}")
    
    def load_preprocessor(self, file_path: str = None):
        """
        Load preprocessor from disk
        
        Args:
            file_path: Path to load file
        """
        if file_path is None:
            file_path = PREPROCESSOR_FILE
        self.preprocessor = joblib.load(file_path)
        logger.info(f"Preprocessor loaded from {file_path}")
    
    def process_data(self, df: pd.DataFrame) -> Tuple[pd.DataFrame, pd.Series]:
        """
        Complete data processing pipeline
        
        Args:
            df: Input DataFrame
            
        Returns:
            Tuple of (features, target)
        """
        # Clean data
        df = self.clean_data(df)
        
        # Convert boolean columns
        df = self.convert_boolean_columns(df)
        
        # Convert target
        df = self.convert_target(df)
        
        # Handle NaN values in target (from unmapped values)
        if df[TARGET_COLUMN].isna().any():
            nan_count = df[TARGET_COLUMN].isna().sum()
            logger.warning(f"Found {nan_count} rows with NaN in target column. Dropping them.")
            df = df.dropna(subset=[TARGET_COLUMN])
        
        # Separate features and target
        X = df[CATEGORICAL_FEATURES + NUMERICAL_FEATURES]
        y = df[TARGET_COLUMN]
        
        logger.info(f"Data processing completed. Features: {X.shape[1]}, Samples: {X.shape[0]}")
        
        return X, y
