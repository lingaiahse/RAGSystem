"""
Utility functions for the Churn Prediction Project
"""

import logging
import json
from pathlib import Path
from datetime import datetime
from typing import Any, Dict

from src.config import LOG_LEVEL, LOG_FORMAT, LOGS_PATH


def setup_logger(name: str) -> logging.Logger:
    """
    Setup a logger with file and console handlers
    
    Args:
        name: Logger name
        
    Returns:
        Configured logger instance
    """
    logger = logging.getLogger(name)
    logger.setLevel(LOG_LEVEL)
    
    # Console handler
    console_handler = logging.StreamHandler()
    console_handler.setLevel(LOG_LEVEL)
    
    # File handler
    log_file = LOGS_PATH / f"{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"
    file_handler = logging.FileHandler(log_file)
    file_handler.setLevel(LOG_LEVEL)
    
    # Formatter
    formatter = logging.Formatter(LOG_FORMAT)
    console_handler.setFormatter(formatter)
    file_handler.setFormatter(formatter)
    
    logger.addHandler(console_handler)
    logger.addHandler(file_handler)
    
    return logger


def save_metadata(metadata: Dict[str, Any], file_path: Path) -> None:
    """
    Save metadata to JSON file
    
    Args:
        metadata: Dictionary to save
        file_path: Path to save file
    """
    with open(file_path, 'w') as f:
        json.dump(metadata, f, indent=4)


def load_metadata(file_path: Path) -> Dict[str, Any]:
    """
    Load metadata from JSON file
    
    Args:
        file_path: Path to metadata file
        
    Returns:
        Loaded metadata dictionary
    """
    with open(file_path, 'r') as f:
        return json.load(f)


def print_section(title: str) -> None:
    """
    Print a formatted section title
    
    Args:
        title: Section title
    """
    print("\n" + "="*60)
    print(f"  {title}")
    print("="*60 + "\n")
