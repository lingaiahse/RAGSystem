"""
Model training for the Churn Prediction Project
"""

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, cross_val_score, GridSearchCV
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    confusion_matrix, classification_report, roc_auc_score, roc_curve
)
import joblib
from typing import Tuple, Dict, Any

from src.config import (
    MODEL_PARAMS, TEST_SIZE, RANDOM_STATE, MODEL_FILE,
    TRAIN_DATA_FILE, TEST_DATA_FILE
)
from src.data_processing import DataProcessor
from src.utils import setup_logger, save_metadata, print_section

logger = setup_logger(__name__)


class ModelTrainer:
    """Train and manage the churn prediction model"""
    
    def __init__(self):
        self.model = None
        self.data_processor = DataProcessor()
        self.metrics = {}
    
    def prepare_data(self, df: pd.DataFrame) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
        """
        Prepare data for model training
        
        Args:
            df: Input DataFrame
            
        Returns:
            Tuple of (X_train, X_test, y_train, y_test)
        """
        logger.info("Preparing data for training...")
        
        # Process data
        X, y = self.data_processor.process_data(df)
        
        # Split data
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=TEST_SIZE, random_state=RANDOM_STATE, stratify=y
        )
        
        logger.info(f"Training set: {X_train.shape}")
        logger.info(f"Test set: {X_test.shape}")
        logger.info(f"Churn ratio in train: {y_train.mean():.2%}")
        logger.info(f"Churn ratio in test: {y_test.mean():.2%}")
        
        # Save datasets
        train_data = X_train.copy()
        train_data['Churn'] = y_train.values
        test_data = X_test.copy()
        test_data['Churn'] = y_test.values
        
        train_data.to_csv(TRAIN_DATA_FILE, index=False)
        test_data.to_csv(TEST_DATA_FILE, index=False)
        logger.info(f"Train data saved to {TRAIN_DATA_FILE}")
        logger.info(f"Test data saved to {TEST_DATA_FILE}")
        
        return X_train, X_test, y_train, y_test
    
    def fit_preprocessor(self, X_train: np.ndarray):
        """
        Fit preprocessor on training data
        
        Args:
            X_train: Training features
        """
        logger.info("Fitting preprocessor...")
        X_train_transformed = self.data_processor.fit_preprocessor(X_train)
        self.data_processor.save_preprocessor()
        return X_train_transformed
    
    def transform_data(self, X_train: np.ndarray, X_test: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        """
        Transform data using fitted preprocessor
        
        Args:
            X_train: Training features
            X_test: Test features
            
        Returns:
            Tuple of (X_train_transformed, X_test_transformed)
        """
        logger.info("Transforming data...")
        X_train_transformed = self.data_processor.fit_preprocessor(X_train)
        X_test_transformed = self.data_processor.transform_data(X_test)
        self.data_processor.save_preprocessor()
        return X_train_transformed, X_test_transformed
    
    def train_random_forest(self, X_train: np.ndarray, y_train: np.ndarray) -> Dict[str, float]:
        """
        Train Random Forest model
        
        Args:
            X_train: Training features
            y_train: Training target
            
        Returns:
            Cross-validation scores
        """
        print_section("TRAINING RANDOM FOREST MODEL")
        
        logger.info("Initializing Random Forest model...")
        self.model = RandomForestClassifier(**MODEL_PARAMS)
        
        logger.info("Training model...")
        self.model.fit(X_train, y_train)
        
        # Cross-validation
        logger.info("Performing cross-validation...")
        cv_scores = cross_val_score(self.model, X_train, y_train, cv=5, scoring='f1')
        logger.info(f"Cross-validation F1 scores: {cv_scores}")
        logger.info(f"Mean CV F1 score: {cv_scores.mean():.4f} (+/- {cv_scores.std():.4f})")
        
        return {
            'mean': cv_scores.mean(),
            'std': cv_scores.std(),
            'scores': cv_scores.tolist()
        }
    
    def train_gradient_boosting(self, X_train: np.ndarray, y_train: np.ndarray) -> Dict[str, float]:
        """
        Train Gradient Boosting model
        
        Args:
            X_train: Training features
            y_train: Training target
            
        Returns:
            Cross-validation scores
        """
        print_section("TRAINING GRADIENT BOOSTING MODEL")
        
        logger.info("Initializing Gradient Boosting model...")
        self.model = GradientBoostingClassifier(
            n_estimators=100,
            max_depth=5,
            learning_rate=0.1,
            random_state=RANDOM_STATE
        )
        
        logger.info("Training model...")
        self.model.fit(X_train, y_train)
        
        # Cross-validation
        logger.info("Performing cross-validation...")
        cv_scores = cross_val_score(self.model, X_train, y_train, cv=5, scoring='f1')
        logger.info(f"Cross-validation F1 scores: {cv_scores}")
        logger.info(f"Mean CV F1 score: {cv_scores.mean():.4f} (+/- {cv_scores.std():.4f})")
        
        return {
            'mean': cv_scores.mean(),
            'std': cv_scores.std(),
            'scores': cv_scores.tolist()
        }
    
    def evaluate_model(self, X_train: np.ndarray, X_test: np.ndarray,
                      y_train: np.ndarray, y_test: np.ndarray) -> Dict[str, Any]:
        """
        Evaluate model on training and test sets
        
        Args:
            X_train: Training features
            X_test: Test features
            y_train: Training target
            y_test: Test target
            
        Returns:
            Evaluation metrics dictionary
        """
        print_section("MODEL EVALUATION")
        
        if self.model is None:
            raise ValueError("Model not trained yet")
        
        # Predictions
        y_train_pred = self.model.predict(X_train)
        y_test_pred = self.model.predict(X_test)
        y_test_pred_proba = self.model.predict_proba(X_test)[:, 1]
        
        # Calculate metrics
        metrics = {
            'train': {
                'accuracy': accuracy_score(y_train, y_train_pred),
                'precision': precision_score(y_train, y_train_pred, zero_division=0),
                'recall': recall_score(y_train, y_train_pred, zero_division=0),
                'f1': f1_score(y_train, y_train_pred, zero_division=0),
            },
            'test': {
                'accuracy': accuracy_score(y_test, y_test_pred),
                'precision': precision_score(y_test, y_test_pred, zero_division=0),
                'recall': recall_score(y_test, y_test_pred, zero_division=0),
                'f1': f1_score(y_test, y_test_pred, zero_division=0),
                'roc_auc': roc_auc_score(y_test, y_test_pred_proba),
            }
        }
        
        self.metrics = metrics
        
        # Print metrics
        print("\nTRAINING METRICS:")
        for metric, value in metrics['train'].items():
            print(f"  {metric.upper()}: {value:.4f}")
        
        print("\nTEST METRICS:")
        for metric, value in metrics['test'].items():
            print(f"  {metric.upper()}: {value:.4f}")
        
        # Confusion matrix
        print("\nCONFUSION MATRIX (Test Set):")
        cm = confusion_matrix(y_test, y_test_pred)
        print(cm)
        
        # Classification report
        print("\nCLASSIFICATION REPORT (Test Set):")
        print(classification_report(y_test, y_test_pred))
        
        metrics['confusion_matrix'] = cm.tolist()
        metrics['classification_report'] = classification_report(y_test, y_test_pred, output_dict=True)
        
        return metrics
    
    def get_feature_importance(self) -> pd.DataFrame:
        """
        Get feature importance from model
        
        Returns:
            DataFrame with feature importance
        """
        if self.model is None:
            raise ValueError("Model not trained yet")
        
        if not hasattr(self.model, 'feature_importances_'):
            raise ValueError("Model does not have feature_importances_ attribute")
        
        feature_names = self.data_processor.feature_names or [f"Feature_{i}" for i in range(len(self.model.feature_importances_))]
        
        importance_df = pd.DataFrame({
            'feature': feature_names,
            'importance': self.model.feature_importances_
        }).sort_values('importance', ascending=False)
        
        print_section("TOP 20 IMPORTANT FEATURES")
        print(importance_df.head(20))
        
        return importance_df
    
    def save_model(self, file_path: str = None):
        """
        Save trained model to disk
        
        Args:
            file_path: Path to save file
        """
        if self.model is None:
            raise ValueError("No model to save")
        
        if file_path is None:
            file_path = MODEL_FILE
        
        joblib.dump(self.model, file_path)
        logger.info(f"Model saved to {file_path}")
    
    def load_model(self, file_path: str = None):
        """
        Load trained model from disk
        
        Args:
            file_path: Path to load file
        """
        if file_path is None:
            file_path = MODEL_FILE
        
        self.model = joblib.load(file_path)
        logger.info(f"Model loaded from {file_path}")
    
    def predict(self, X: np.ndarray) -> np.ndarray:
        """
        Make predictions
        
        Args:
            X: Features
            
        Returns:
            Predictions
        """
        if self.model is None:
            raise ValueError("Model not trained or loaded")
        
        return self.model.predict(X)
    
    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        """
        Get prediction probabilities
        
        Args:
            X: Features
            
        Returns:
            Prediction probabilities
        """
        if self.model is None:
            raise ValueError("Model not trained or loaded")
        
        return self.model.predict_proba(X)
