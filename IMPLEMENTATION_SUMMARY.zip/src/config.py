"""
Configuration file for the Churn Prediction Project
"""

import os
from pathlib import Path

# Project paths
PROJECT_ROOT = Path(__file__).parent.parent
DATA_PATH = PROJECT_ROOT / "DataSet"
MODEL_PATH = PROJECT_ROOT / "model"
NOTEBOOKS_PATH = PROJECT_ROOT / "notebooks"
LOGS_PATH = PROJECT_ROOT / "logs"

# Create logs directory if it doesn't exist
os.makedirs(LOGS_PATH, exist_ok=True)
os.makedirs(MODEL_PATH, exist_ok=True)

# Data configuration
DATA_FILE = DATA_PATH / "telco_churn.csv"
TRAIN_DATA_FILE = MODEL_PATH / "train_data.csv"
TEST_DATA_FILE = MODEL_PATH / "test_data.csv"

# Model configuration
MODEL_FILE = MODEL_PATH / "churn_model.pkl"
PREPROCESSOR_FILE = MODEL_PATH / "preprocessor.pkl"
MODEL_METADATA = MODEL_PATH / "model_metadata.json"

# Feature configuration
CATEGORICAL_FEATURES = [
    'gender', 'SeniorCitizen', 'Partner', 'Dependents',
    'PhoneService', 'MultipleLines', 'InternetService',
    'OnlineSecurity', 'OnlineBackup', 'DeviceProtection',
    'TechSupport', 'StreamingTV', 'StreamingMovies',
    'Contract', 'PaperlessBilling', 'PaymentMethod'
]

NUMERICAL_FEATURES = [
    'tenure', 'MonthlyCharges', 'TotalCharges'
]

TARGET_COLUMN = 'Churn'

# Model hyperparameters
MODEL_PARAMS = {
    'n_estimators': 100,
    'max_depth': 10,
    'min_samples_split': 5,
    'min_samples_leaf': 2,
    'random_state': 42,
    'n_jobs': -1
}

# Train/Test split
TEST_SIZE = 0.2
RANDOM_STATE = 42

# API configuration
API_HOST = "0.0.0.0"
API_PORT = 8000
DEBUG = False

# Logging configuration
LOG_LEVEL = "INFO"
LOG_FORMAT = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
