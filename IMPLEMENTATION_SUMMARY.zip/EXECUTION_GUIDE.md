# Quick Execution Guide

## Step-by-Step Usage

### Step 0: Install Dependencies (First Time Only)

```bash
pip install -r requirements.txt
```

---

## Step 1: Run Full Training Pipeline ⭐ RECOMMENDED

Complete analysis with EDA, training, and evaluation:

```bash
python main.py
```

**What it does:**
- ✅ Loads telco_churn.csv
- ✅ Performs EDA (exploratory data analysis)
- ✅ Generates 9 visualization files
- ✅ Cleans and preprocesses data
- ✅ Trains Random Forest model
- ✅ Evaluates model (accuracy, precision, recall, F1, ROC-AUC)
- ✅ Calculates feature importance
- ✅ Saves trained model & preprocessor
- ✅ Generates metrics report

**Output:**
```
✓ Model saved to model/churn_model.pkl
✓ Preprocessor saved to model/preprocessor.pkl
✓ Metadata saved to model/model_metadata.json
✓ Visualizations saved to notebooks/
✓ Training data saved to model/train_data.csv
✓ Test data saved to model/test_data.csv
```

**Time:** ~2-3 minutes

---

## Step 2: View Visualizations

Check generated plots in `notebooks/` folder:

```bash
# List visualization files
ls notebooks/

# View specific images
# - 01_churn_distribution.png
# - 02_numerical_distributions.png
# - 03_correlation_heatmap.png
# - 04_churn_by_contract.png
# - 05_churn_by_internet_service.png
# - confusion_matrix.png
# - roc_curve.png
# - precision_recall_curve.png
# - feature_importance.png
```

---

## Step 3: Start API Server

```bash
python -m uvicorn api.main:app --reload --port 8000
```

**Output:**
```
Uvicorn running on http://127.0.0.1:8000
Press CTRL+C to quit
```

---

## Step 4: Access API Documentation

Open in browser:
```
http://localhost:8000/docs
```

You'll see interactive Swagger UI with:
- All endpoints
- Request/response examples
- Try-it-out interface

---

## Step 5: Test API Endpoints

### Option A: Using Swagger UI (Easiest)

1. Go to http://localhost:8000/docs
2. Click on any endpoint
3. Click "Try it out"
4. Fill in parameters
5. Click "Execute"
6. See response

### Option B: Using Python Script

```bash
python test_api.py
```

### Option C: Using cURL

```bash
# Health check
curl http://localhost:8000/health

# Single prediction
curl -X POST http://localhost:8000/predict \
  -H "Content-Type: application/json" \
  -d '{
    "gender": "Female",
    "SeniorCitizen": 0,
    "Partner": "Yes",
    "Dependents": "No",
    "tenure": 12,
    "PhoneService": "Yes",
    "MultipleLines": "No",
    "InternetService": "Fiber optic",
    "OnlineSecurity": "No",
    "OnlineBackup": "No",
    "DeviceProtection": "Yes",
    "TechSupport": "Yes",
    "StreamingTV": "Yes",
    "StreamingMovies": "Yes",
    "Contract": "Month-to-month",
    "PaperlessBilling": "Yes",
    "PaymentMethod": "Electronic check",
    "MonthlyCharges": 99.99,
    "TotalCharges": 1299.87
  }'
```

### Option D: Using Python Requests

```python
import requests

customer_data = {
    "gender": "Female",
    "SeniorCitizen": 0,
    "Partner": "Yes",
    "Dependents": "No",
    "tenure": 12,
    "PhoneService": "Yes",
    "MultipleLines": "No",
    "InternetService": "Fiber optic",
    "OnlineSecurity": "No",
    "OnlineBackup": "No",
    "DeviceProtection": "Yes",
    "TechSupport": "Yes",
    "StreamingTV": "Yes",
    "StreamingMovies": "Yes",
    "Contract": "Month-to-month",
    "PaperlessBilling": "Yes",
    "PaymentMethod": "Electronic check",
    "MonthlyCharges": 99.99,
    "TotalCharges": 1299.87
}

response = requests.post("http://localhost:8000/predict", json=customer_data)
result = response.json()

print(f"Churn Probability: {result['probability_churn']:.1%}")
print(f"Risk Level: {result['risk_level']}")
print(f"Prediction: {'CHURN' if result['prediction'] == 1 else 'NO CHURN'}")
```

---

## Step 6: Deploy with Docker (Optional)

### Option A: Docker

```bash
# Build image
docker build -t churn-prediction:latest .

# Run container
docker run -p 8000:8000 churn-prediction:latest

# Open browser
http://localhost:8000/docs
```

### Option B: Docker Compose

```bash
# Start services
docker-compose up -d

# View logs
docker-compose logs -f

# Stop services
docker-compose down
```

---

## Complete Workflow Example

```bash
# Terminal 1: Training
$ python main.py
Loading data from DataSet/telco_churn.csv
Data shape: (7043, 21)
...
✓ Model saved successfully

# Terminal 2: Start API
$ python -m uvicorn api.main:app --reload
Uvicorn running on http://127.0.0.1:8000

# Browser: Test Predictions
# Open http://localhost:8000/docs
# Try endpoints in Swagger UI

# Terminal 3: Batch Testing
$ python test_api.py
Testing API at: http://localhost:8000

🔍 Testing health endpoint...
Status: 200

🔍 Testing single prediction...
Status: 200
Prediction: {
  "prediction": 1,
  "probability_churn": 0.75,
  "risk_level": "HIGH"
}

✅ All tests completed!
```

---

## Expected Results

### After main.py

**Console Output:**
```
============================================================
  CHURN PREDICTION - COMPLETE PIPELINE
============================================================

============================================================
  STEP 1: LOADING DATA
============================================================
Loading data from DataSet/telco_churn.csv
Data shape: (7043, 21)

============================================================
  STEP 2: EXPLORATORY DATA ANALYSIS
============================================================

============================================================
  BASIC DATASET INFORMATION
============================================================
Shape: (7043, 21)
...

============================================================
  STEP 5: MODEL TRAINING
============================================================
Training model...
Performing cross-validation...
Mean CV F1 score: 0.5847 (+/- 0.0324)

============================================================
  STEP 6: MODEL EVALUATION
============================================================
TRAINING METRICS:
  ACCURACY: 0.8132
  PRECISION: 0.6485
  RECALL: 0.5551
  F1: 0.5976

TEST METRICS:
  ACCURACY: 0.8068
  PRECISION: 0.6295
  RECALL: 0.5331
  F1: 0.5794
  ROC_AUC: 0.8407

============================================================
PIPELINE COMPLETED SUCCESSFULLY
============================================================
✓ Model saved to model/churn_model.pkl
✓ Preprocessor saved to model/preprocessor.pkl
✓ Metadata saved to model/model_metadata.json
✓ Visualizations saved to notebooks/
✓ Training data saved to model/train_data.csv
✓ Test data saved to model/test_data.csv
```

### Prediction Response Example

```json
{
  "prediction": 1,
  "probability_no_churn": 0.248,
  "probability_churn": 0.752,
  "risk_level": "HIGH",
  "timestamp": "2024-06-03T10:30:45.123456"
}
```

---

## Troubleshooting

### Issue: ModuleNotFoundError
```bash
# Solution: Install requirements
pip install -r requirements.txt
```

### Issue: Port 8000 in use
```bash
# Solution: Use different port
python -m uvicorn api.main:app --port 8001
```

### Issue: Model not found
```bash
# Solution: Run training first
python main.py
```

### Issue: "Connection refused"
```bash
# Solution: Make sure API is running
python -m uvicorn api.main:app --reload
```

### Issue: CORS errors
```bash
# Already handled in api/main.py
# Allows requests from any origin
```

---

## Performance Metrics

The trained model achieves:

| Metric | Value |
|--------|-------|
| Accuracy | ~81% |
| Precision | ~63% |
| Recall | ~53% |
| F1-Score | ~58% |
| ROC-AUC | ~0.84 |

**Interpretation:**
- 81% of predictions are correct
- Of predicted churners, 63% actually churned
- Of actual churners, model caught 53%
- ROC-AUC of 0.84 indicates good discriminative power

---

## File Management

### View Logs
```bash
# Linux/Mac
tail -f logs/*.log

# Windows
type logs\*.log

# Or open in text editor
```

### View Model Info
```bash
# View metadata
python -c "import json; print(json.load(open('model/model_metadata.json')))"
```

### Export Predictions
```python
import pandas as pd

# Load test data
test_df = pd.read_csv('model/test_data.csv')

# Make predictions
from src.model_loader import ModelLoader
model, preprocessor = ModelLoader.load_model_and_preprocessor()
predictions = model.predict(preprocessor.transform(test_df.drop('Churn', axis=1)))

# Save results
results = pd.DataFrame({
    'actual': test_df['Churn'],
    'predicted': predictions
})
results.to_csv('predictions.csv', index=False)
```

---

## Next Steps

1. ✅ **Run Training**: `python main.py`
2. ✅ **View Visualizations**: Check `notebooks/` folder
3. ✅ **Start API**: `python -m uvicorn api.main:app --reload`
4. ✅ **Test Predictions**: Use Swagger UI at `/docs`
5. ✅ **Deploy**: Use Docker or cloud platform
6. ✅ **Monitor**: Check `logs/` and API metrics

---

## Important Files

| File | Purpose |
|------|---------|
| `main.py` | **RUN THIS FIRST** - Complete training |
| `api/main.py` | API endpoints |
| `test_api.py` | Test suite |
| `README.md` | Full documentation |
| `GETTING_STARTED.md` | Quick start |
| `PROJECT_STRUCTURE.md` | File descriptions |

---

**Ready to start?** Run `python main.py` now! 🚀
