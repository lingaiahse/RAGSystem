# Getting Started Guide

Complete guide to getting started with the Churn Prediction Project.

## Quick Start (2 minutes)

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Run Quick Training
```bash
python app.py
```

This will:
- Load and clean data
- Show churn statistics
- Train a quick model
- Save results to model/ folder

## Full Pipeline (10 minutes)

### Run Complete Analysis
```bash
python main.py
```

This generates:
- **EDA Report** with statistics
- **Visualizations** (charts, graphs, correlations)
- **Trained Model** (Random Forest)
- **Evaluation Metrics** (accuracy, precision, recall, F1, ROC-AUC)
- **Feature Importance** analysis
- **Training & Test Data** for reproducibility

**Output:**
```
✓ Model saved to model/churn_model.pkl
✓ Preprocessor saved to model/preprocessor.pkl
✓ Metadata saved to model/model_metadata.json
✓ Visualizations saved to notebooks/
✓ Training data saved to model/train_data.csv
✓ Test data saved to model/test_data.csv
```

## API Deployment

### Option 1: Local Server

```bash
# Start API
python -m uvicorn api.main:app --reload --port 8000

# Open in browser
http://localhost:8000/docs
```

### Option 2: Docker

```bash
# Single container
docker build -t churn-prediction:latest .
docker run -p 8000:8000 churn-prediction:latest

# Or with Docker Compose
docker-compose up -d

# View logs
docker-compose logs -f
```

## Using the API

### Health Check
```bash
curl http://localhost:8000/health
```

**Response:**
```json
{
  "status": "healthy",
  "model_loaded": true,
  "timestamp": "2024-06-03T10:30:45.123456"
}
```

### Single Prediction

**Using curl:**
```bash
curl -X POST http://localhost:8000/predict \
  -H "Content-Type: application/json" \
  -d '{
    "gender": "Female",
    "SeniorCitizen": 0,
    "Partner": "Yes",
    "Dependents": "No",
    "tenure": 12,
    "PhoneService": "Yes",
    "MultipleLines": "No",
    "InternetService": "Fiber optic",
    "OnlineSecurity": "No",
    "OnlineBackup": "No",
    "DeviceProtection": "Yes",
    "TechSupport": "Yes",
    "StreamingTV": "Yes",
    "StreamingMovies": "Yes",
    "Contract": "Month-to-month",
    "PaperlessBilling": "Yes",
    "PaymentMethod": "Electronic check",
    "MonthlyCharges": 99.99,
    "TotalCharges": 1299.87
  }'
```

**Using Python:**
```python
import requests

customer = {
    "gender": "Female",
    "SeniorCitizen": 0,
    "Partner": "Yes",
    "Dependents": "No",
    "tenure": 12,
    "PhoneService": "Yes",
    "MultipleLines": "No",
    "InternetService": "Fiber optic",
    "OnlineSecurity": "No",
    "OnlineBackup": "No",
    "DeviceProtection": "Yes",
    "TechSupport": "Yes",
    "StreamingTV": "Yes",
    "StreamingMovies": "Yes",
    "Contract": "Month-to-month",
    "PaperlessBilling": "Yes",
    "PaymentMethod": "Electronic check",
    "MonthlyCharges": 99.99,
    "TotalCharges": 1299.87
}

response = requests.post("http://localhost:8000/predict", json=customer)
result = response.json()

print(f"Churn Probability: {result['probability_churn']:.2%}")
print(f"Risk Level: {result['risk_level']}")
```

**Response:**
```json
{
  "prediction": 1,
  "probability_no_churn": 0.25,
  "probability_churn": 0.75,
  "risk_level": "HIGH",
  "timestamp": "2024-06-03T10:30:45.123456"
}
```

### Batch Prediction

```bash
# See test_api.py for full example
python test_api.py
```

## Project Structure

```
ChurnProject/
├── src/
│   ├── config.py           # Configuration & constants
│   ├── utils.py            # Utility functions
│   ├── data_processing.py  # Data cleaning & preprocessing
│   ├── eda.py              # Exploratory data analysis
│   ├── model_training.py   # Model training
│   ├── model_evaluation.py # Evaluation metrics
│   └── model_loader.py     # Model loading utilities
├── api/
│   └── main.py             # FastAPI application
├── model/                  # Trained models & data
├── DataSet/                # Input data
├── notebooks/              # Generated visualizations
├── logs/                   # Application logs
├── main.py                 # Training pipeline
├── app.py                  # Quick start script
├── test_api.py             # API test suite
├── Dockerfile              # Docker configuration
├── docker-compose.yml      # Docker Compose config
├── requirements.txt        # Dependencies
└── README.md              # Full documentation
```

## Configuration

Edit `src/config.py` to customize:

```python
# Model hyperparameters
MODEL_PARAMS = {
    'n_estimators': 100,      # Number of trees
    'max_depth': 10,          # Tree depth
    'min_samples_split': 5,
    'min_samples_leaf': 2,
    'random_state': 42,
}

# Train/test split
TEST_SIZE = 0.2              # 80/20 split
RANDOM_STATE = 42

# API settings
API_HOST = "0.0.0.0"
API_PORT = 8000
DEBUG = False
```

## Features & Data

### Input Features

**Categorical:**
- gender, Partner, Dependents, PhoneService
- MultipleLines, InternetService, OnlineSecurity, OnlineBackup
- DeviceProtection, TechSupport, StreamingTV, StreamingMovies
- Contract, PaperlessBilling, PaymentMethod

**Numerical:**
- tenure (months), MonthlyCharges, TotalCharges

### Target Variable
- Churn: Yes/No (converted to 1/0)

## Monitoring & Logs

Logs are automatically saved to `logs/` with timestamps.

```bash
# View logs
tail -f logs/*.log

# Check for errors
grep ERROR logs/*.log
```

## Advanced Usage

### Hyperparameter Tuning

Edit `src/config.py` and rerun `python main.py`:

```python
MODEL_PARAMS = {
    'n_estimators': 150,       # Try more trees
    'max_depth': 15,           # Increase depth
    'min_samples_split': 3,
    'min_samples_leaf': 1,
}
```

### Using Gradient Boosting Instead

Modify `main.py`:

```python
# Replace this:
cv_scores_rf = trainer.train_random_forest(X_train_transformed, y_train)

# With this:
cv_scores_gb = trainer.train_gradient_boosting(X_train_transformed, y_train)
```

### Retraining with New Data

```python
# Update the dataset and run:
python main.py

# This will:
# - Overwrite old model
# - Save new preprocessor
# - Update evaluation metrics
```

## Troubleshooting

### Issue: "Model not found"
```bash
# Solution: Train the model first
python main.py
```

### Issue: "Port 8000 already in use"
```bash
# Solution: Use different port
python -m uvicorn api.main:app --port 8001
```

### Issue: "Import errors"
```bash
# Solution: Install dependencies
pip install -r requirements.txt
```

### Issue: "Docker build fails"
```bash
# Solution: Clear cache and rebuild
docker build --no-cache -t churn-prediction:latest .
```

### Issue: "Out of memory"
```python
# Solution: Reduce batch size or use smaller dataset
# Edit src/config.py and reduce n_estimators or max_depth
```

## Performance Metrics

Expected model performance:
- **Accuracy**: ~80%
- **Precision**: ~60% (of predicted churners, 60% actually churned)
- **Recall**: ~55% (of actual churners, caught 55%)
- **F1-Score**: ~57% (harmonic mean)
- **ROC-AUC**: ~0.84 (good discriminative ability)

## Next Steps

1. ✅ Run `python main.py` to train the model
2. ✅ Check visualizations in `notebooks/` folder
3. ✅ Start API with `python -m uvicorn api.main:app --reload`
4. ✅ Test with `python test_api.py`
5. ✅ Deploy with Docker or cloud platform
6. ✅ Monitor predictions in `logs/` folder

## Support

For detailed information, see:
- [README.md](README.md) - Full documentation
- [src/config.py](src/config.py) - Configuration reference
- [api/main.py](api/main.py) - API documentation
- FastAPI docs: http://localhost:8000/docs (when API running)

## Quick Commands Reference

```bash
# Training
python main.py                                    # Full pipeline
python app.py                                    # Quick start

# API
python -m uvicorn api.main:app --reload         # Start server
python test_api.py                              # Test API

# Docker
docker build -t churn-prediction:latest .       # Build image
docker-compose up -d                            # Start containers
docker-compose down                             # Stop containers
docker-compose logs -f                          # View logs

# Data
python -c "from src.eda import *; ..."          # Access modules
```

---

Happy predicting! 🚀
